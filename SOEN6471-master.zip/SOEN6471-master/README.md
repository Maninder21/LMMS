SOEN6471-LMMS-Project
=====================


Winter 2014
============


Milestone-4 LMMS fork


Group Members
=============


Pavleen Kaur Batra My ID: 9754733


Sardar Maninder Singh ID:6555519




LMMS-(Linux MultiMedia Studio)
============================

LMMS is a free cross-platform alternative to commercial programs like FL Studio (R), which allow you to produce music with your computer. This includes the creation of melodies and beats, the synthesis and mixing of sounds, and arranging of samples. You can have fun with your MIDI-keyboard and much more; all in a user-friendly and modern interface.

